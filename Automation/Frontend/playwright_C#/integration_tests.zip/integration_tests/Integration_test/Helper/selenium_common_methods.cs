﻿using Microsoft.Playwright;
using Microsoft.Playwright.MSTest;
using OpenQA.Selenium;
using OpenQA.Selenium.BiDi.Modules.BrowsingContext;
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.WaitHelpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integration_test.Helper
{
    public class selenium_common_methods
    {
        private IPage _page;
        public selenium_common_methods(IPage page)
        {
            _page = page;
        }

        public async Task<int> wait_for_element_presentAsync(string locator)
        {
            var locator_ = _page.Locator(locator);
            if (locator_.IsVisibleAsync().Result)
                return int.Parse(locator_.TextContentAsync().Result);
            else
                return 0;
        }

        public void navigate(string url)
        {
            _page.GotoAsync(url);
        }

        public async void SendText(string selector, string value, string locator = "")
            {
            if (locator == "")
            {
                await _page.Locator("'//*[@id='" + selector + "']'").FillAsync(value);
            }
            if (locator == "text")
            {
                await _page.GetByText(selector).FillAsync(value);
            }
            else
            {
                await _page.Locator(selector).FillAsync(value);
            }
           
        }

        public async void ClickElement(String selector,string locator="")
        {
            if (locator == "")
            {
                await _page.Locator("'//*[@id='"+selector+"']'").ClickAsync();
            }
            if (locator == "text")
            {
                await _page.GetByText(selector).ClickAsync();
            }
            else
            {
                await _page.Locator(selector).ClickAsync();
            }

        }

        public async void wait_for_selector(string selector)
        {
           _page.WaitForSelectorAsync(selector);

        }

        public void SelectDropdownByCLicking(string selector1, string selector2)

        {
            ClickElement(selector1,"xpath");
            Thread.Sleep(3000);
            ClickElement(selector2, "xpath");
        }

        public async void SelectDropdown(string selector, string value)
        {

            var locator_q = _page.Locator(selector);
            
            

            var dropDownList = _page.Locator(selector);
            dropDownList.SelectOptionAsync(value);

        }

        public async Task<string> GetTitle()
        {
            Thread.Sleep(2000);
            string title = await _page.TitleAsync();
            return title;
        }

        public  async void assert_with_text(string locator, string text)
        {
            await Assertions.Expect(_page.Locator(locator)).ToContainTextAsync(text);
            }

        //accepts only xpath or id
        public async Task<bool> IsElementPresent(string locator)
        {
            try
            {
                Console.WriteLine("value of inner text is "+ _page.Locator(locator).InnerTextAsync());
                if (await _page.Locator(locator).CountAsync() > 0)
                { return true; }
                else { return false; } 
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }

    }
}
