﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.Reporter;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Reqnroll;

[assembly: Parallelizable(ParallelScope.Fixtures)]

namespace TeamNameTestScripts.Hooks
{
    [Binding]
    public sealed class Hooks
    {
        static string configTheme = "standard";
        //static string configReportPath = @$"C:\Users\LKO090\source\repos\Integration_test\Integration_test\Reports\ExtentReport.html";
        
        
        static string configReportPath = Path.Combine((Directory.GetCurrentDirectory()).Split("bin")[0], "Reports", "ExtentReport.html");


        [ThreadStatic]
        private static ExtentTest feature;
        [ThreadStatic]
        private static ExtentTest scenario;
        private static ExtentReports extentReport;
        private static readonly string base64ImageType = "base64";


        [BeforeTestRun]
        public static void InitializeReport()
        {
            //Initialize Extent report before test starts
            ExtentSparkReporter htmlReporter = new ExtentSparkReporter(configReportPath);
            Console.WriteLine("path of report is "+configReportPath);
            //switch (configTheme.ToLower())
            //{
            //    case "dark":
            //        htmlReporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Dark;
            //        break;
            //    case "standard":
            //    default:
            //        htmlReporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Standard;
            //        break;
            //}

            //Attach report to reporter
            extentReport = new ExtentReports();
            extentReport.AttachReporter(htmlReporter);
        }

        [AfterTestRun]
        public static void TearDownReport()
        {
            extentReport.Flush();
        }

        [BeforeFeature]
        public static void BeforeFeature(FeatureContext featureContext)
        {
            feature = extentReport.CreateTest<Feature>(featureContext.FeatureInfo.Title);
        }

        [BeforeScenario]
        public void InitializeScenario(FeatureContext featureContext, ScenarioContext scenarioContext)
        {
            scenario = feature.CreateNode<Scenario>(scenarioContext.ScenarioInfo.Title);
        }

        [AfterScenario]
        public void CleanUp(ScenarioContext scenarioContext)
        {
            //to check if we missed to implement any step
            string resultOfImplementation = scenarioContext.ScenarioExecutionStatus.ToString();

            //Pending Status
            if (resultOfImplementation == "UndefinedStep")
            {
                // Log.StepNotDefined();
            }
        }

        [AfterStep("api")]
        public void InsertReportingSteps(ScenarioContext scenarioContext)
        {
            string stepType = scenarioContext.StepContext.StepInfo.StepDefinitionType.ToString();
            string stepInfo = scenarioContext.StepContext.StepInfo.Text;


            //to check if we missed to implement steps inside method
            string resultOfImplementation = scenarioContext.ScenarioExecutionStatus.ToString();


            if (scenarioContext.TestError == null && resultOfImplementation == "OK")
            {
                if (stepType == "Given")
                    scenario.CreateNode<Given>(stepInfo);
                else if (stepType == "When")
                    scenario.CreateNode<When>(stepInfo);
                else if (stepType == "Then")
                    scenario.CreateNode<Then>(stepInfo);
                else if (stepType == "And")
                    scenario.CreateNode<And>(stepInfo);
                else if (stepType == "But")
                    scenario.CreateNode<And>(stepInfo);
            }
            else if (scenarioContext.TestError != null)
            {
                Exception? innerException = scenarioContext.TestError.InnerException;
                string? testError = scenarioContext.TestError.Message;

                if (stepType == "Given")
                    scenario.CreateNode<Given>(stepInfo).Fail(innerException, MediaEntityBuilder.CreateScreenCaptureFromBase64String(base64ImageType).Build());
                else if (stepType == "When")
                    scenario.CreateNode<When>(stepInfo).Fail(innerException, MediaEntityBuilder.CreateScreenCaptureFromBase64String(base64ImageType).Build());
                else if (stepType == "Then")
                    scenario.CreateNode<Then>(stepInfo).Fail(testError, MediaEntityBuilder.CreateScreenCaptureFromBase64String(base64ImageType).Build());
                else if (stepType == "And")
                    scenario.CreateNode<Then>(stepInfo).Fail(testError, MediaEntityBuilder.CreateScreenCaptureFromBase64String(base64ImageType).Build());
                else if (stepType == "But")
                    scenario.CreateNode<Then>(stepInfo).Fail(testError, MediaEntityBuilder.CreateScreenCaptureFromBase64String(base64ImageType).Build());

            }
            else if (resultOfImplementation == "StepDefinitionPending")
            {
                string errorMessage = "Step Definition is not implemented!";

                if (stepType == "Given")
                    scenario.CreateNode<Given>(stepInfo).Fail(errorMessage, MediaEntityBuilder.CreateScreenCaptureFromBase64String(base64ImageType).Build());
                else if (stepType == "When")
                    scenario.CreateNode<When>(stepInfo).Fail(errorMessage, MediaEntityBuilder.CreateScreenCaptureFromBase64String(base64ImageType).Build());
                else if (stepType == "Then")
                    scenario.CreateNode<Then>(stepInfo).Fail(errorMessage, MediaEntityBuilder.CreateScreenCaptureFromBase64String(base64ImageType).Build());
                else if (stepType == "But")
                    scenario.CreateNode<Then>(stepInfo).Fail(errorMessage, MediaEntityBuilder.CreateScreenCaptureFromBase64String(base64ImageType).Build());

            }

        }

    }
}




//namespace ApiFramework
//{
//    [Binding]
//    class hook : TechTalk.SpecFlow.Steps
//    {
//        private static ExtentTest featureName;
//        private static ExtentTest scenario;
//        private static ExtentReports extent;
//        [BeforeTestRun]
//        public static void InitializeReport()
//        {
//            //string projectPath = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName;
//            //string folderName = Path.Comb"ine(projectPath, "reporting");
//            Directory.CreateDirectory("C:\\Users\\LKO090\\source\\repos\\Integration_test\\Integration_test\\reporting\\");

//            string currentDirectory = Directory.GetCurrentDirectory();
//            var project_path = currentDirectory.Split("bin")[0];
//            string filePath = Path.Combine(project_path, "reporting");

//            //File.SetAttributes("C:\\Automation\\Report", FileAttributes.Normal);
//            ExtentSparkReporter htmlReporter = new ExtentSparkReporter(filePath);

//            extent = new ExtentReports();
//            extent.AttachReporter(htmlReporter);
//        }
//        [AfterTestRun]
//        public static void TearDownReport()
//        {
//            extent.Flush();
//        }
//        [AfterStep]
//        public void InsertReportingSteps(ScenarioContext sc)
//        {
//            var stepType = ScenarioStepContext.Current.StepInfo.StepDefinitionType.ToString();
//            PropertyInfo pInfo = typeof(ScenarioContext).GetProperty("ScenarioExecutionStatus", BindingFlags.Instance | BindingFlags.Public);
//            MethodInfo getter = pInfo.GetGetMethod(nonPublic: true);
//            object TestResult = getter.Invoke(sc, null);
//            if (sc.TestError == null)
//            {
//                if (stepType == "Given")
//                    scenario.CreateNode<Given>(ScenarioStepContext.Current.StepInfo.Text);
//                else if (stepType == "When")
//                    scenario.CreateNode<When>(ScenarioStepContext.Current.StepInfo.Text);
//                else if (stepType == "Then")
//                    scenario.CreateNode<Then>(ScenarioStepContext.Current.StepInfo.Text);
//                else if (stepType == "And")
//                    scenario.CreateNode<And>(ScenarioStepContext.Current.StepInfo.Text);
//            }
//            if (sc.TestError != null)
//            {
//                if (stepType == "Given")
//                    scenario.CreateNode<Given>(ScenarioStepContext.Current.StepInfo.Text).Fail(sc.TestError.Message);
//                if (stepType == "When")
//                    scenario.CreateNode<When>(ScenarioStepContext.Current.StepInfo.Text).Fail(sc.TestError.Message);
//                if (stepType == "Then")
//                    scenario.CreateNode<Then>(ScenarioStepContext.Current.StepInfo.Text).Fail(sc.TestError.Message);
//                if (stepType == "And")
//                    scenario.CreateNode<And>(ScenarioStepContext.Current.StepInfo.Text).Fail(sc.TestError.Message);
//            }
//        }
//        [BeforeFeature]
//        public static void BeforeFeature(FeatureContext featurecontext)
//        {
//            featureName = extent.CreateTest(featurecontext.FeatureInfo.Title);
//        }
//    }
//}
//{
//    [Binding]

//    public class hook
//    {
//        //public static ExtentReports extent;
//        public static ExtentTest test;
//        public static ExtentReports extent;
//        public static ExtentTest testlog;


//        //[BeforeFeature("this is params of feature")]
//        //[OneTimeSetUp]
//        [BeforeTestRun]
//        public static void StartReport()
//        {
//            var htmlReporter = new ExtentSparkReporter("C:\\Users\\LKO090\\source\\repos\\Integration_test\\Integration_test\\Reports");

//            extent = new ExtentReports();
//            extent.AttachReporter(htmlReporter);

//            //Console.WriteLine("here***********^^^^^^");
//            //string path = Assembly.GetCallingAssembly().CodeBase;
//            //string actualPath = path.Substring(0, path.LastIndexOf("bin"));
//            //string projectPath = new Uri(actualPath).LocalPath;

//            //string reportPath = projectPath + "Reports\\";

//            //System.IO.Directory.CreateDirectory(reportPath);
//            //ExtentSparkReporter htmlReporter = new ExtentSparkReporter(reportPath);
//            //extent = new ExtentReports();
//            //extent.AttachReporter(htmlReporter);

//            //extent.AddSystemInfo("Environment", "QA");
//            //extent.AddSystemInfo("Tester", Environment.UserName);
//            //extent.AddSystemInfo("MachineName", Environment.MachineName);

//        }

//        [AfterTestRun]
//        public static void EndReport()
//        {
//            LoggingTestStatusExtentReport();
//            extent.Flush();

//        }
//        public static void StartExtentTest(string testsToStart)
//        {
//            Console.WriteLine("inside start extent report " + testsToStart);
//            testlog = extent.CreateTest(testsToStart);
//        }


//        public static void LoggingTestStatusExtentReport()
//        {

//                var status = TestContext.CurrentContext.Result.Outcome.Status;
//                var stacktrace = string.Empty + TestContext.CurrentContext.Result.StackTrace + string.Empty;
//                var errorMessage = TestContext.CurrentContext.Result.Message;
//                Status logstatus;
//                switch (status)
//                {
//                    case TestStatus.Failed:
//                        logstatus = Status.Fail;
//                        testlog.Log(Status.Fail, "Test steps NOT Completed for Test case " + TestContext.CurrentContext.Test.Name + " ");
//                        testlog.Log(Status.Fail, "Test ended with " + Status.Fail + " – " + errorMessage);
//                        break;
//                    case TestStatus.Skipped:
//                        logstatus = Status.Skip;
//                        testlog.Log(Status.Skip, "Test ended with " + Status.Skip);
//                        break;
//                    default:
//                        logstatus = Status.Pass;
//                        testlog.Log(Status.Pass, "Test steps finished for test case " + TestContext.CurrentContext.Test.Name);
//                        testlog.Log(Status.Pass, "Test ended with " + Status.Pass);
//                        break;
//                }




//        //    [BeforeScenario()]
//        //public static void BeforeScenarioSetUp()
//        //{
//        //    Console.WriteLine("this is start of scenario");
//        //    // string testName = TestContext.CurrentContext.Test.Name;
//        //    //string testName = ScenarioContext.Current.ScenarioInfo.Title;
//        //    ////  testName = FeatureContext.Current.FeatureInfo.Title;
//        //    //test = extent.CreateTest(testName);
//        //}

//            ////[AfterScenario()]
//            ////public static void AfterScnario()
//            ////{

//            ////}

//            //[AfterScenario()]
//            //public static void EndReport()
//            //{
//            //    Console.WriteLine("this is end of report");
//            //    //extent.Flush();

//            //    //string workingDirectory = Environment.CurrentDirectory;
//            //    //System.IO.DirectoryInfo di = new DirectoryInfo(workingDirectory);

//            //    //if (di.GetFiles().Count() > Convert.ToInt32(ConfigurationManager.AppSettings["FileCount"]))
//            //    //{
//            //    //    foreach (FileInfo file in di.GetFiles())
//            //    //    {
//            //    //        try
//            //    //        {
//            //    //            file.Delete();
//            //    //        }
//            //    //        catch (Exception e)
//            //    //        {
//            //    //            //Existing log will not get deleted as its been used by other process. 
//            //    //        }
//            //    //    }
//            //        //foreach (DirectoryInfo dir in di.GetDirectories()) // not needed as there will be no directory in this folder.
//            //        //{
//            //        //    dir.Delete(true);
//            //        //}
//            //    }
//            //}
//        } }




//    }
////}