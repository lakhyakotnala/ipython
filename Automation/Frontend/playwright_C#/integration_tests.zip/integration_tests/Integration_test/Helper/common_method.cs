﻿using Integration_test.locators;
using Microsoft.Playwright;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integration_test.Helper
{
    public class common_method
    {
        private IPage _page;
        protected playwright_common_methods utilities;
        protected p2u_page_locator locator_custom;
        public common_method(IPage page)
        {
            _page = page;
            utilities = new playwright_common_methods(page);
            locator_custom = new p2u_page_locator();
        }


        public void login_custom_p2u_app()
        {

            Thread.Sleep(3000);
            utilities.wait_for_selector(locator_custom.username_p2u);
            utilities.ClickElement(locator_custom.username_p2u, "xpath");
            Thread.Sleep(6000);
            utilities.ClickElement(locator_custom.submit_btn, "xpath");
            Thread.Sleep(3000);
            
        }



    }
}
