﻿using Integration_test.locators;
using Microsoft.Playwright;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Reqnroll;
using Microsoft.Playwright;
using Microsoft.Playwright.NUnit;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.BiDi.Communication;

namespace Integration_test.Helper
{
    public class base_class_UI
    {
        public IWebDriver driver;
        public p2u_page_locator locator_custom;
        public playwright_common_methods utilities_pr;
        public common_method common_methods_pr;
        /// <summary>
        public static IBrowser browser;
        private IBrowser context1;

        public IPage page { get; private set; } = null!; //-> We'll call this property in the tests



        [BeforeScenario("@UITest")]
        public async Task Setup_pr()
        {
            var playwright = await Playwright.CreateAsync();
            browser = await playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions
            {
                Headless = false, // -> Use this option to be able to see your test running
                Args = new List<string> { "--start-maximized" }
            });
            //// Setup a browser context
            var context1 = await browser.NewContextAsync(new BrowserNewContextOptions
            {
                IgnoreHTTPSErrors = true,
                ViewportSize = ViewportSize.NoViewport
            });

            page = await context1.NewPageAsync();

            locator_custom = new p2u_page_locator();
            common_methods_pr = new common_method(page);
            utilities_pr = new playwright_common_methods(page);

        }



        [AfterScenario("@UITest")]
        public void TearDown()
        {
            browser.CloseAsync();


        }
    }
}
