﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Integration_test.locators
{
    public class p2u_page_locator
    {

        public string username_p2u = "//li[@class='member']//a";
        public string submit_btn = "//button[@id='form-submit1']";
        public string username_error = "//div[@id='username']//span[@class='error-text'][contains(text(),'입력하신 정보를 확인해주세요.')]";
        public string password_error = "//div[@id='password']//span[@class='error-text'][contains(text(),'입력하신 정보를 확인해주세요.')]";

        
    }

}
