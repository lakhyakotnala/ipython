﻿using System;
using Integration_test.Helper;
using Reqnroll;

namespace Integration_test.Tests.StepDefinition
{
    [Binding]
    public class DemoStepDefinitions : base_class_UI
    {
        //[Given("a user with access to p{int}u application")]
        //public void GivenAUserWithAccessToPuApplication(int p0)
        //{
        //    utilities_pr.navigate("https://dev.p2u.kr/");
        //}

        [Given("a user with access to p{int}u application")]
        public void GivenAUserWithAccessToPuApplication(int p0)
        {
            utilities_pr.navigate("https://dev.p2u.kr/");
        }


        [When("he navigates to app and try to login with incorrect credentials")]
        public void WhenHeNavigatesToAppAndTryToLoginWithIncorrectCredentials()
        {
            common_methods_pr.login_custom_p2u_app();
        }

        [Then("he should be able view error in doing so")]
        public void ThenHeShouldBeAbleViewErrorInDoingSo()
        {
            utilities_pr.assert_with_text(locator_custom.username_error, "입력하신 정보를 확인해주세요.");
            
        }

        [Given("a user with access to p{int}u application opens a product")]
        public void GivenAUserWithAccessToPuApplicationOpensAProduct(int p0)
        {
            utilities_pr.navigate("https://dev.p2u.kr/");
        }


        [When("he navigates to app and buy a product")]
        public void WhenHeNavigatesToAppAndBuyAProduct()
        {
            utilities_pr.ClickElement("(//a[contains(text(),'히트상품')])[1]", "xpath");
            Thread.Sleep(8000);
            utilities_pr.ClickElement("//a[contains(text(),'[글로벌G] 알지쓰리 블랙라벨 (60ml x 10포 x 3박스)')]", "xpath");
            Thread.Sleep(25000);
            utilities_pr.ClickElement("//button[@id='sit_btn_buy']", "xpath");
            


        }
        
        [Then("he should be able view error as non member product")]
        public void ThenHeShouldBeAbleViewErrorAsNonMemberProduct()
        {
            utilities_pr.assert_with_text("//a[contains(text(),'비회원 구매하기')]", "비회원 구매하기");
        }


    }
}
